package com.hospital.ml.service;

import com.hospital.ml.entity.DoctorsEntity;
import com.hospital.ml.service.common.AbstractService;

public interface DoctorsEntityService extends AbstractService<DoctorsEntity, Integer> {
}